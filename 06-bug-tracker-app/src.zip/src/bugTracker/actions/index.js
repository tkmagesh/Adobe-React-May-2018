import { addNew } from './addNew';
import { toggle } from './toggle';
import { removeClosed } from './removeClosed';

let bugActions = { addNew, toggle, removeClosed };

export default bugActions;
